#ifndef  __PWM_H
#define  __PWM_H
void PWM_SetCompare1(unsigned int Compare);
void PWM_SetCompare2(unsigned int Compare);


void PWM_Init(void);
#endif
