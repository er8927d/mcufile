#ifndef __LED_H
#define __LED_H

void LED_Init(void);
void BUZZER_ON(void);
void BUZZER_OFF(void);


#endif
