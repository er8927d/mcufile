#include "stm32f10x.h"                  // Device header
#include  "PWM.h"

void Servo_Init(void)
{
	PWM_Init();
}

void Servo_SetAngle(float Angle1,float Angle2)
{
	PWM_SetCompare1(Angle1 / 270 * 2000 + 500);//500
	PWM_SetCompare2(Angle2 / 270 * 2000 + 500);//500
}
