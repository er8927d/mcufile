#ifndef __SERVO_H
#define __SERVO_H
void Servo_SetAngle(float Angle1,float Angle2);
void Servo_Init(void);

#endif
