#ifndef __Timer_H__
#define __Timer_H__

void Timer_Init(void);

#endif
