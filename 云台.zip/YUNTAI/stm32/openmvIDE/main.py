import sensor, time, image, pyb, os, tf, uos, gc
import time
import ustruct
from pyb import UART
import lcd
sensor.set_brightness(3)
sensor.set_gainceiling(16)
lcd.set_backlight(255)
lcd.init()
RED_LED_PIN = 1
BLUE_LED_PIN = 3
b=1
num = 4
a=-1
uart = UART(3, 9600,timeout_char=3000)
sensor.reset()
while(True):
   if(a == 10):
	  a=-1
   if(a == -1):
	  a = uart.readchar()
   if(a == 1):
		   num = uart.readchar()
		   if(num>=0):
				print(num)
				a = uart.readchar()
   if(a == 2):
		print(num)
		sensor.set_pixformat(sensor.GRAYSCALE)
		sensor.set_framesize(sensor.QQVGA2)
		sensor.set_windowing((128,160))
		sensor.skip_frames(10)
		sensor.skip_frames(time = 2000)
		n = 50
		def sending_data(cx,cy,cw,ch):
			global uart;
			data = ustruct.pack("<bbhb",
						   0x2C,
						   0x12,
						   int (cx),
						   0x5B)
			uart.write(data);
		while(n):
			lcd.display(sensor.snapshot())
			pyb.LED(RED_LED_PIN).on()
			sensor.skip_frames(time = 700)
			lcd.display(sensor.snapshot())
			pyb.LED(RED_LED_PIN).off()
			pyb.LED(BLUE_LED_PIN).on()
			print(n)
			sensor.snapshot().save("face/%s/%s.pgm" % (num, n) )
			lcd.display(sensor.snapshot())
			n -= 1
			pyb.LED(BLUE_LED_PIN).off()
			print("Done! Reset the camera to see the saved image.")
			if(n == 50):
				FH = bytearray([0x2C,0x12,15,0x5B])
				uart.write(FH)
			elif(n == 1):
				FH = bytearray([0x2C,0x12,16,0x5B])
				uart.write(FH)
		num+=1
		a = uart.readchar()
   if(a == 3):
		print(num)
		sensor.set_pixformat(sensor.GRAYSCALE)
		sensor.set_framesize(sensor.QQVGA2)
		sensor.set_windowing((128,160))
		sensor.skip_frames(10)
		NUM_SUBJECTS = num-1
		NUM_SUBJECTS_IMGS = 20
		RED_LED_PIN = 1
		BLUE_LED_PIN = 3
		pyb.LED(RED_LED_PIN).on()
		sensor.skip_frames(time = 500)
		pyb.LED(RED_LED_PIN).off()
		img = sensor.snapshot()
		lcd.display(sensor.snapshot())
		d0 = img.find_lbp((0, 0, img.width(), img.height()))
		img = None
		pmin = 999999
		Num=0
		def sending_data(cx,cy,cw,ch):
			global uart;
			data = ustruct.pack("<bbhb",
						   0x2C,
						   0x12,
						   int (cx),
						   0x5B)
			uart.write(data);
		def min(pmin, a, s):
			global Num
			if a<pmin:
				pmin=a
				Num=s
			return pmin
		b=0
		for s in range(1, NUM_SUBJECTS+1):
			dist = 001
			for i in range(2, NUM_SUBJECTS_IMGS+1):
				img = image.Image("face/%d/%d.pgm"%(s, i))
				d1 = img.find_lbp((0, 0, img.width(), img.height()))
				dist += image.match_descriptor(d0, d1)
			print("Average dist for subject %d: %d"%(s, dist/NUM_SUBJECTS_IMGS))
			pmin = min(pmin, dist/NUM_SUBJECTS_IMGS, s)
			print(pmin)
			if(pmin>8300):
				b+=1
		if(b == NUM_SUBJECTS):
			Num = 14
		FH = bytearray([0x2C,0x12,Num,0x5B])
		for i in range (1,10):
			uart.write(FH)
			i+=1
		print(Num)
		a = uart.readchar()
   if(a==4):
		sensor.set_pixformat(sensor.RGB565)
		sensor.set_framesize(sensor.QQVGA2)
		sensor.set_windowing((240,240))
		pyb.LED(RED_LED_PIN).on()
		sensor.skip_frames(time=500)
		pyb.LED(RED_LED_PIN).off()
		net = None
		labels = None
		try:
			net = tf.load("trained.tflite", load_to_fb=uos.stat('trained.tflite')[6] > (gc.mem_free() - (64*1024)))
		except Exception as e:
			print(e)
			raise Exception('Failed to load "trained.tflite", did you copy the .tflite and labels.txt file onto the mass-storage device? (' + str(e) + ')')
		try:
			labels = [line.rstrip('\n') for line in open("labels.txt")]
		except Exception as e:
			raise Exception('Failed to load "labels.txt", did you copy the .tflite and labels.txt file onto the mass-storage device? (' + str(e) + ')')
		clock = time.clock()
		def sending_data(cx,cy,cw,ch):
			global uart;
			data = ustruct.pack("<bbhb",
						   0x2C,
						   0x12,
						   int (cx),
						   0x5B)
			uart.write(data);
		clock.tick()
		while(a == -1 or a==4):
			img = sensor.snapshot()
			lcd.display(sensor.snapshot())
			for obj in net.classify(img, min_scale=1.0, scale_mul=0.8, x_overlap=0.5, y_overlap=0.5):
				print("**********\nPredictions at [x=%d,y=%d,w=%d,h=%d]" % obj.rect())
				predictions_list = list(zip(labels, obj.output()))
				for i in range(len(predictions_list)):
					print("%s = %f" % (predictions_list[i][0], predictions_list[i][1]))
			if(predictions_list[0][1] >= predictions_list[1][1]):
			 Num = 11
			else:
			 Num = 12
			FH = bytearray([0x2C,0x12,Num,0x5B])
			print(clock.fps(), "fps")
			a = uart.readchar()
			uart.write(FH)