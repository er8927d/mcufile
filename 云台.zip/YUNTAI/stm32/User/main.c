#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include "Key.h"
#include "sys.h"
#include "LED.h"
#include "Servo.h"
float i;
unsigned int KeyNum;
float Ang1,Ang2,AngFlag;
float Angle1,Angle2;
int main(void)
{
	OLED_Init();
	Key_Init();
	Serial_Init();
	Servo_Init();
//	OLED_ShowString(2,1,"1:");
//	OLED_ShowString(3,1,"2:");
	Servo_SetAngle(0,0);
			Delay_ms(500);	
     	Servo_SetAngle(90,65);
//	  
//	OLED_ShowNum(2,3,Angle1,3);
//	OLED_ShowNum(3,+3,Angle2,3);
//	Delay_ms(2000);
//	
	while (1)
{
	Servo_SetAngle(90,0);	
	
		for(i=0;i<=270;i++)
			{
				Delay_ms(50);//80
				Servo_SetAngle(90,i);
				
			}Servo_SetAngle(90,270);	
			
			
			
		KeyNum = Key_GetNum();
		if (KeyNum == 1)
		{
			for(i=65;i<=79;i++)
			{
				Delay_ms(60);//80
				Servo_SetAngle(90,i);
				
			}Servo_SetAngle(90,80);	
			for(i=90;i>=77;i--)
			{
				Delay_ms(60);//80
				Servo_SetAngle(i,80);
				
			}Servo_SetAngle(77,80);	
			for(i=80;i>=54;i--)
			{
				Delay_ms(60);//40
				Servo_SetAngle(77,i);
				
			}Servo_SetAngle(77,55);
				Delay_ms(300);
			for(i=77;i<105;i++)
			{
				Delay_ms(60);//40
				Servo_SetAngle(i,54.5);
				
			}Servo_SetAngle(104,54.5);	     	
			for(i=55;i<=80;i++)
			{
				Delay_ms(60);//40
				Servo_SetAngle(104,i);
				
			}Servo_SetAngle(104,80);	    
			for(i=104;i>=91;i--)
			{
				Delay_ms(60);//40
				Servo_SetAngle(i,80);
				
			}Servo_SetAngle(91,80);
			for(i=80;i>=66;i--)
			{
				Delay_ms(60);//40
				Servo_SetAngle(91,i);
				
			}Servo_SetAngle(91,66.5);
			Delay_ms(1000);
			
		}
		
		
	    
            if (KeyNum == 2)
		{
			for(i=65;i<=70;i++)
			{
				Delay_ms(60);//80
				Servo_SetAngle(90,i);
				
			}Servo_SetAngle(90,70);	
			for(i=90;i>=81;i--)
			{
				Delay_ms(60);//80
				Servo_SetAngle(i,70);
				
			}Servo_SetAngle(81,70);	
			for(i=70;i>=60;i--)
			{
				Delay_ms(60);//80
				Servo_SetAngle(81,i);
				
			}Servo_SetAngle(81,60);	
			for(i=81;i<=97;i++)
			{
				Delay_ms(60);//80
				Servo_SetAngle(i,60);
				
			}Servo_SetAngle(97,60);	     	
			for(i=60;i<=69;i++)
			{
				Delay_ms(60);//80
				Servo_SetAngle(97,i);
				
			}Servo_SetAngle(97,69.5);	    
			for(i=97;i>=90;i--)
			{
				Delay_ms(60);//80
				Servo_SetAngle(i,70);
				
			}Servo_SetAngle(90,70);
		}
			
		
	}
}


