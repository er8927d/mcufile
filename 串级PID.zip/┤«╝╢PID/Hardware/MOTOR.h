#ifndef __MOTOR_H
#define __MOTOR_H

void left(int8_t speed);
void left(int8_t speed);
void right_f(uint8_t speed);
void right_b(uint8_t speed);

#endif
