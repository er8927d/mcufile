/*

�������
������1�õ�TIM3��CH1��CH2,��PA6��PA7
�����PWM�õ�TIM2,PA0��PA1�����·ͨ��

*/
#include "stm32f10x.h"        
#include "LED.H"
#include "DELAY.H"
#include "PWM.H"
#include "MOTOR.H"
#include "ENCODER.H"
#include "PID.H"
#include "OLED.H"
#include "serial.H"

#define tar_psoition    2000*10
#define tar_speed       20

uint8_t time,key;
int16_t now_speed,now_position;
float pwm;


int main(void)
{
    LED_Init();
    PWM_Init();
    Encoder_Init();
    OLED_Init();
    Serial_Init();

	OLED_ShowString(1, 1, "counter: ");
    OLED_ShowString(2, 1, "pwm: ");
    while(1)
    {
        OLED_ShowSignedNum(1, 10, now_speed, 3);
		OLED_ShowSignedNum(2, 10, pwm, 3);
        printf("%d\n",now_position);
        //printf("%d\n",now_speed);
        //left(pwm);
    }
}

void TIM2_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)
	{
        time++;
        if(time==10)
        {
            now_speed=Encoder_Get();
            now_position+=now_speed;
            pwm=p_pid(now_position,tar_psoition);
            pwm=limit(pwm,tar_speed);
			if(myabs(tar_psoition-now_position)<5)
				left(0);
			else
			{
				pwm=i_pid(now_speed,pwm);
				left(pwm);
			}
            time=0;
        }
        
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
	}
}

